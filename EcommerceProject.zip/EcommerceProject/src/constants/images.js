// const home = require("../../assets/images/airpods.jpg");
// const notification = require("../../assets/images/airpods.jpg");
// export default {
//   home,
//   notification,
// };
